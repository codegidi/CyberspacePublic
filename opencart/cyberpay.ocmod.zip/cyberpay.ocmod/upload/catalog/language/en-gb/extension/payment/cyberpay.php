<?php
// Text
$_['text_title'] = 'Cyberpay (Mastercard and Visa)';
